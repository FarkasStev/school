%
% CS 430 P5 (Prolog 1)
%
% Name:
%

parent(_,_).

step_parent(_,_).

sibling(_,_).

aunt_uncle(_,_).

grandparent(_,_).

ancestor(_,_).

relative(_,_).

in_law(_,_).
