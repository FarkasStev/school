package measurement;

/**
 * @author Steven Farkas
 *
 *         I have neither given nor received any unauthorized aid on this assignment. This
 *         assignment complies with the JMU Honor Code.
 */
public class Temperature implements Comparable<Temperature>
{

  private double degrees;
  private Scale scale;

  /**
   * Constructs a Temperature of 0.0 degrees F.
   */
  public Temperature()
  {
    degrees = 0.0;
    scale = Scale.F;
  }

  /**
   * Constructs a copy of the given Temperature object.
   * 
   * @param other
   *          Tempurature to copy
   */
  public Temperature(final Temperature other)
  {
    this.degrees = other.degrees;
    this.scale = other.scale;
  }

  /**
   * Constructs a Tempurature with the given degrees in Fahrenheit.
   * 
   * @param degrees
   *          degrees in fahrenheit to initialize with
   */
  public Temperature(final double degrees)
  {
    this.degrees = degrees;
    this.scale = Scale.F;
  }

  /**
   * Constructs a Temperature object with the given degrees and Scale.
   * 
   * @param degrees
   *          to be used
   * @param scale
   *          to be used as a String
   */
  public Temperature(final double degrees, final String scale)
  {
    this.degrees = degrees;
    this.scale = Scale.createScale(scale);
  }

  /**
   * Constructs a Temperature object with the given degrees and Scale.
   * 
   * @param degrees
   *          to be used
   * @param scale
   *          to be used as a String
   */
  public Temperature(final double degrees, final Scale scale)
  {
    this.degrees = degrees;
    this.scale = scale;
  }

  /**
   * Creates a Temperature object from the given terse String representation. Returns the default
   * Temperature if the String is not a valid terse representation.
   * 
   * @param s
   *          String to create Temperature from
   * @return Temperature object created
   */
  public static Temperature createTemperature(final String s)
  {
    if (s == null || s.length() != 7)
    {
      return new Temperature();
    }
    String tempString = s.stripLeading();
    if (tempString.charAt(0) != '+' && tempString.charAt(0) != '-')
    {
      return new Temperature();
    }
    double tempDegree = 0.0;
    String tempScale = "F";

    tempDegree = Double.parseDouble(tempString.substring(0, tempString.length() - 1));
    tempScale = tempString.substring(tempString.length() - 1);

    return new Temperature(tempDegree, Scale.createScale(tempScale));

  }

  @Override
  public int compareTo(final Temperature other)
  {
    if (degrees > other.convert(scale))
    {
      return 1;
    }
    else if (degrees == other.convert(scale))
    {
      return 0;
    }
    return -1;
  }

  /**
   * Decreases the owning Temperature by the given Temperature, accounting for Scale differences.
   * This method does not change the scale attribute of either Temperature.
   * 
   * @param amount
   *          converted
   */
  public void decreaseBy(final Temperature amount)
  {

    degrees -= amount.convert(scale);

  }

  /**
   * Parses a terse String representation of a Temperature and change the attributes of the owning
   * Temperature appropriately. If there is a problem with the String representation then it leaves
   * the attributes of the owning Temperature unchanged
   * 
   * @param s
   *          String representation to be changed to
   */
  public void fromString(final String s)
  {
    if (s != null && s.length() == 7)
    {

      String tempString = s.stripLeading();
      if (tempString.charAt(0) == '+' || tempString.charAt(0) == '-')
      {

        double tempDegree = degrees;
        String tempScale = scale.toString();

        tempDegree = Double.parseDouble(tempString.substring(0, tempString.length() - 1));
        tempScale = tempString.substring(tempString.length() - 1);

        degrees = tempDegree;
        scale = Scale.createScale(tempScale);
      }
    }

  }

  /**
   * Increases the owning Temperature by the given Temperature, accounting for Scale differences.
   * This method does not change the scale attribute of either Temperature.
   * 
   * @param amount
   *          increased by
   */
  public void increaseBy(final Temperature amount)
  {
    degrees += amount.convert(scale);
  }

  /**
   * Returns a terseString representation of the owning Temperature. The numeric part of the String
   * representation begins with a sign indicator, and is in a field of width 6 with one place to the
   * right of the decimal. The numeric part is followed immediately by the terse representation of
   * the scale attribute.
   * 
   * @return String representation
   */
  public String toString()
  {
    return toString(scale);
  }

  /**
   * Returns a terse String representation of the owning Temperature using the given Scale (which
   * may or may not be different from the Scale of the owning Temperature).
   * 
   * @param scaleToUse
   *          representation to use
   * @return terse String representation
   */
  public String toString(final Scale scaleToUse)
  {
    return String.format("%+6.1f" + scaleToUse.toString(), convert(scaleToUse));
  }

  /**
   * Private helper method that converts into the given Scale. Could easily be refactored to include
   * other scales.
   * 
   * @param other
   *          Scale to convert from
   * @return converted double value
   */
  private double convert(final Scale other)
  {

    if (scale.equals(Scale.F) && other.equals(Scale.C))
    {
      return (degrees - 32) * (5 / 9);
    }
    else if (scale.equals(Scale.C) && other.equals(Scale.F))
    {
      return (degrees * (9 / 5)) + 32;
    }
    return degrees;

  }
}
