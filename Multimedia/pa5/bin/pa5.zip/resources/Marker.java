package resources;

/**
 * A class that is used to mark the location of resources so that they
 * can easily be found using a ResourceFinder.
 * 
 * @author  Prof. David Bernstein, James Madison University
 * @version 2.0
 */
public class Marker
{
}
